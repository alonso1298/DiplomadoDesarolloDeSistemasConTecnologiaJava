package unam.diplomado.pixup.notification.domain;

public class Notificacion {
}
