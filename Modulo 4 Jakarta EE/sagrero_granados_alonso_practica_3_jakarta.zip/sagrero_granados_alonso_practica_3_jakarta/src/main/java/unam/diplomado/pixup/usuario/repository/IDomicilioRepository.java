package unam.diplomado.pixup.usuario.repository;

import unam.diplomado.pixup.usuario.domain.Domicilio;

public interface IDomicilioRepository {

    Domicilio save(Domicilio domicilio);

}
