package unam.diplomado.pixup.disco.service;

import unam.diplomado.pixup.disco.domain.Disco;

public interface IDiscoService {
    Disco registrarDisco(Disco disco);
}
